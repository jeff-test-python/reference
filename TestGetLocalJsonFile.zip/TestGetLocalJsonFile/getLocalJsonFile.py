import json

with open('config.json') as config:
    data = config.read()

obj = json.loads(data)

com_id = str(obj['com_id'])