# 參考資料： https://docs.python.org/3/library/configparser.html

try:
    import configparser  # python3
except ImportError:
    from six.moves import configparser  # python2

config = configparser.ConfigParser()
config.read('config.ini')  # 載入參數檔

print(config.sections())  # 查看所有 section


def show_default_section():
    print(config['default']['host'])
    print(config['default']['port'])
    print(config['default']['username'])
    print(config['default']['password'])


def set_default_section(host: str, port: str, username: str, password: str):
    config['default'] = {
        'host': host,
        'port': port,
        'username': username,
        'password': password
    }


show_default_section()
set_default_section('111', '222', '333', '444')
show_default_section()

config['default']['port'] = '9487'

show_default_section()

# 產出當前的數據(另存於 test.ini)
with open('test.ini', 'w') as configfile:
    config.write(configfile)

flag = config['test'].getint('flag')
print(flag)
flag = config['test'].getboolean('flag')
print(flag)
flag = config['test'].getfloat('flag')
print(flag)

flag = config.get('test', 'flag')
print(flag)
flag = config.get('default', 'flag', fallback='prod_database')  # section 或 key 沒有對應值時的預設值
print(flag)
