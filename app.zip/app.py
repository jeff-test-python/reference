import requests
import urllib3

urllib3.disable_warnings()


def fetchData():
    response = requests.get("https://opendata.epa.gov.tw/ws/Data/ATM00756/?$format=json", verify=False)

    status_code = response.status_code
    print status_code

    content = response.content
    print type(content)
    #print content

    text = response.text
    print type(text)
    #print text

    json = response.json
    print type(json)
    #print json

    headers = response.headers
    print headers

#fetchData()


def getDict():
    url='http://httpbin.org/get'
    params={'name':'iaodeng','sex':1}
    r=requests.get(url,params=params)
    print r.status_code
    print r.text

#getDict()


def getHeader():
    url='http://httpbin.org/get'
    headers={'x-header1':'value1','x-header2':'value2'}
    r=requests.get(url,headers=headers)
    print r.status_code
    print r.text

#getHeader()


def getCookie():
    headers={'User-Agent':'chrome'}
    url='http://www.douban.com'
    r=requests.get(url,headers=headers)
    print r.status_code
    print r.cookies
    print r.cookies['bid']

getCookie()
